from flask import Flask, render_template, jsonify
import os
from dotenv import load_dotenv
import requests

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__, static_folder='static', static_url_path='/static')

# Get API key from environment variables
API_KEY = os.getenv('WEATHER_API_KEY')

@app.route('/')
def index():
    return render_template('xpost.html')

@app.route('/weather')
def weather():
    return render_template('weather.html')

@app.route('/api/weather')
def get_weather():
    url = f"http://api.weatherapi.com/v1/forecast.json?key={API_KEY}&q=Ulaanbaatar&days=7&aqi=yes&alerts=yes"
    response = requests.get(url)
    if response.status_code == 200:
        return jsonify(response.json())
    else:
        return jsonify({"error": "Unable to fetch weather data"}), 500

@app.route('/api/placeholder/<int:width>/<int:height>')
def placeholder(width, height):
    return f'<svg width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg"><rect width="100%" height="100%" fill="#ddd"/><text x="50%" y="50%" font-family="Arial" font-size="14" fill="#333" text-anchor="middle" dy=".3em">{width}x{height}</text></svg>', 200, {'Content-Type': 'image/svg+xml'}

if __name__ == '__main__':
    app.run(debug=True)