import os
from dotenv import load_dotenv
from flask import Flask, jsonify
import requests

app = Flask(__name__)

# Load environment variables from .env file
load_dotenv()

# Get the API key from the environment variable
api_key = os.getenv('WEATHER_API_KEY')

@app.route('/api/weather')
def get_weather():
    url = f"http://api.weatherapi.com/v1/forecast.json?key={api_key}&q=Ulaanbaatar&days=7"
    
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        return jsonify(data)
    else:
        return jsonify({"error": "Unable to fetch weather data"}), 500

if __name__ == '__main__':
    app.run(debug=False)