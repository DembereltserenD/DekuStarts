// Google Tag Manager
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-KV4Q4DPP');
    
    document.addEventListener('DOMContentLoaded', () => {
        // Ticker functionality
        const tickerItems = document.querySelectorAll('.ticker-item');
        let currentIndex = 0;
        const itemCount = tickerItems.length;
    
        function showItem(index) {
            tickerItems.forEach(item => item.classList.remove('active', 'prev'));
            tickerItems[index].classList.add('active');
            tickerItems[(index - 1 + itemCount) % itemCount].classList.add('prev');
        }
    
        function nextItem() {
            currentIndex = (currentIndex + 1) % itemCount;
            showItem(currentIndex);
        }
    
        function prevItem() {
            currentIndex = (currentIndex - 1 + itemCount) % itemCount;
            showItem(currentIndex);
        }
    
        const nextButton = document.querySelector('.ticker-nav .next');
        const prevButton = document.querySelector('.ticker-nav .prev');
    
        if (nextButton && prevButton) {
            nextButton.addEventListener('click', nextItem);
            prevButton.addEventListener('click', prevItem);
        }
    
        // Auto-advance every 3 seconds
        let autoAdvance = setInterval(nextItem, 3000);
    
        // Pause auto-advance when hovering over the ticker
        const tickerWrapper = document.querySelector('.ticker-wrapper');
        if (tickerWrapper) {
            tickerWrapper.addEventListener('mouseenter', () => clearInterval(autoAdvance));
            tickerWrapper.addEventListener('mouseleave', () => {
                autoAdvance = setInterval(nextItem, 5000);
            });
        }
    
        // Swipeable menu functionality
        const menuContainer = document.getElementById('menuContainer');
        const menuToggle = document.querySelector('.menu-toggle');
        let touchStartX = 0;
        let touchEndX = 0;
    
        function handleGesture() {
            if (touchStartX - touchEndX > 50) {
                // Swipe left
                menuContainer.classList.remove('opened');
            }
            if (touchEndX - touchStartX > 50) {
                // Swipe right
                menuContainer.classList.add('opened');
            }
        }
    
        if (menuContainer) {
            menuContainer.addEventListener('touchstart', e => {
                touchStartX = e.changedTouches[0].screenX;
            });
    
            menuContainer.addEventListener('touchend', e => {
                touchEndX = e.changedTouches[0].screenX;
                handleGesture();
            });
        }
    
        if (menuToggle && menuContainer) {
            menuToggle.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent this click from being caught by the document click listener
                menuContainer.classList.toggle('opened');
            });
        }
    
        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (menuContainer && !e.target.closest('.menu-container') && !e.target.closest('.menu-toggle')) {
                menuContainer.classList.remove('opened');
            }
        });
    
        // Prevent clicks inside the menu from closing it
        if (menuContainer) {
            menuContainer.addEventListener('click', (e) => {
                e.stopPropagation();
            });
        }
    
        // Weather link hover effect
        const weatherLink = document.getElementById('weatherLink');
        if (weatherLink) {
            weatherLink.addEventListener('mouseenter', () => {
                weatherLink.setAttribute('data-city', 'Улаанбаатар');
            });
    
            weatherLink.addEventListener('mouseleave', () => {
                weatherLink.removeAttribute('data-city');
            });
        }
    
        // Handle window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth > 768 && menuContainer) {
                menuContainer.classList.remove('opened');
            }
        });
    
        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
    
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    });