document.addEventListener('DOMContentLoaded', function() {
    fetchWeatherData();
});

function fetchWeatherData() {
    fetch('/api/weather')
        .then(response => response.json())
        .then(data => {
            updateCurrentWeather(data.current, data.forecast.forecastday[0].astro);
            updateHourlyForecast(data.forecast.forecastday[0].hour);
            updateWeeklyForecast(data.forecast.forecastday);
            updateAirQuality(data.current.air_quality);
            createTemperatureChart(data.forecast.forecastday[0].hour);
            createPrecipitationChart(data.forecast.forecastday[0].hour);
            updateLastUpdated(data.current.last_updated);
        })
        .catch(error => console.error('Цаг агаарын мэдээлэл авахад алдаа гарлаа:', error));
}

function updateCurrentWeather(current, astro) {
    document.getElementById('currentWeatherIcon').src = current.condition.icon;
    document.getElementById('currentTemperature').textContent = `${current.temp_c}°C`;
    document.getElementById('currentCondition').textContent = translateCondition(current.condition.text);
    document.getElementById('feelsLike').textContent = `Мэдрэгдэх температур: ${current.feelslike_c}°C`;
    document.getElementById('currentHumidity').textContent = `Чийгшил: ${current.humidity}%`;
    document.getElementById('currentWind').textContent = `Салхи: ${current.wind_kph} км/ц ${translateWindDirection(current.wind_dir)}`;
    document.getElementById('currentPressure').textContent = `Даралт: ${current.pressure_mb} мб`;
    document.getElementById('currentVisibility').textContent = `Харагдац: ${current.vis_km} км`;
    document.getElementById('currentUV').textContent = `UV индекс: ${current.uv}`;
    document.getElementById('sunrise').textContent = `Нар мандах: ${astro.sunrise}`;
    document.getElementById('sunset').textContent = `Нар жаргах: ${astro.sunset}`;
}

function updateHourlyForecast(hourlyData) {
    const container = document.getElementById('hourlyForecast');
    container.innerHTML = '';

    const now = new Date();
    const currentHour = now.getHours();

    hourlyData.slice(currentHour, currentHour + 24).forEach(hour => {
        const hourDiv = document.createElement('div');
        hourDiv.className = 'forecast-item';
        hourDiv.innerHTML = `
            <p class="forecast-time">${new Date(hour.time).getHours()}:00</p>
            <img src="${hour.condition.icon}" alt="${translateCondition(hour.condition.text)}" class="forecast-icon">
            <p class="forecast-temp">${hour.temp_c}°C</p>
            <p class="forecast-precip">${hour.chance_of_rain}% бороо</p>
        `;
        container.appendChild(hourDiv);
    });
}

function updateWeeklyForecast(weeklyData) {
    const container = document.getElementById('weeklyForecast');
    container.innerHTML = '';

    const mongolianDays = ['Ням', 'Даваа', 'Мягмар', 'Лхагва', 'Пүрэв', 'Баасан', 'Бямба'];

    weeklyData.forEach(day => {
        const date = new Date(day.date);
        const dayName = mongolianDays[date.getDay()];
        const dayDiv = document.createElement('div');
        dayDiv.className = 'forecast-item';
        dayDiv.innerHTML = `
            <p class="forecast-day">${dayName}</p>
            <img src="${day.day.condition.icon}" alt="${translateCondition(day.day.condition.text)}" class="forecast-icon">
            <p class="forecast-temp">${day.day.avgtemp_c}°C</p>
            <p class="forecast-desc">${translateCondition(day.day.condition.text)}</p>
            <p class="forecast-precip">${day.day.daily_chance_of_rain}% бороо</p>
        `;
        container.appendChild(dayDiv);
    });
}

function updateAirQuality(airQuality) {
    const aqiElement = document.getElementById('airQualityIndex');
    const aqiDescElement = document.getElementById('airQualityDesc');
    const aqi = airQuality['us-epa-index'];
    
    aqiElement.textContent = aqi;
    
    const aqiDescriptions = [
        'Сайн',
        'Дунд',
        'Эмзэг бүлгийнхэнд хортой',
        'Хортой',
        'Маш хортой',
        'Аюултай'
    ];
    
    aqiDescElement.textContent = aqiDescriptions[aqi - 1] || 'Тодорхойгүй';
}

function createTemperatureChart(hourlyData) {
    const ctx = document.getElementById('temperatureChart').getContext('2d');
    const labels = hourlyData.map(hour => `${new Date(hour.time).getHours()}:00`);
    const temperatures = hourlyData.map(hour => hour.temp_c);

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Температур (°C)',
                data: temperatures,
                borderColor: 'rgb(255, 99, 132)',
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: '24 цагийн температурын урьдчилсан мэдээ'
                }
            },
            scales: {
                y: {
                    beginAtZero: false
                }
            }
        }
    });
}

function createPrecipitationChart(hourlyData) {
    const ctx = document.getElementById('precipitationChart').getContext('2d');
    const labels = hourlyData.map(hour => `${new Date(hour.time).getHours()}:00`);
    const precipProb = hourlyData.map(hour => hour.chance_of_rain);

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Хур тунадасны магадлал (%)',
                data: precipProb,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgb(54, 162, 235)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: '24 цагийн хур тунадасны урьдчилсан мэдээ'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

function updateLastUpdated(lastUpdated) {
    const element = document.getElementById('lastUpdated');
    const date = new Date(lastUpdated);
    element.textContent = `Сүүлд шинэчилсэн: ${date.toLocaleString('mn-MN')}`;
}

function translateCondition(condition) {
    const conditionMap = {
        'Clear': 'Цэлмэг',
        'Sunny': 'Нартай',
        'Partly cloudy': 'Үүлэрхэг',
        'Cloudy': 'Үүлтэй',
        'Overcast': 'Бүрхэг',
        'Mist': 'Манантай',
        'Patchy rain possible': 'Бага зэргийн бороо орох магадлалтай',
        'Patchy snow possible': 'Бага зэргийн цас орох магадлалтай',
        'Patchy sleet possible': 'Бага зэргийн шивэр тунадас орох магадлалтай',
        'Patchy freezing drizzle possible': 'Бага зэргийн хүйтэн шиврээ орох магадлалтай',
        'Thundery outbreaks possible': 'Аянга цахилгаантай бороо орох магадлалтай',
        // Add more translations as needed
    };
    return conditionMap[condition] || condition;
}

function translateWindDirection(direction) {
    const directionMap = {
        'N': 'Хойд',
        'NNE': 'Хойд-Зүүн хойд',
        'NE': 'Зүүн хойд',
        'ENE': 'Зүүн-Зүүн хойд',
        'E': 'Зүүн',
        'ESE': 'Зүүн-Зүүн өмнөд',
        'SE': 'Зүүн өмнөд',
        'SSE': 'Өмнөд-Зүүн өмнөд',
        'S': 'Өмнөд',
        'SSW': 'Өмнөд-Баруун өмнөд',
        'SW': 'Баруун өмнөд',
        'WSW': 'Баруун-Баруун өмнөд',
        'W': 'Баруун',
        'WNW': 'Баруун-Баруун хойд',
        'NW': 'Баруун хойд',
        'NNW': 'Хойд-Баруун хойд'
    };
    return directionMap[direction] || direction;
}